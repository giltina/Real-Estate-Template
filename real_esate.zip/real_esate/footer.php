<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Tinashe
 */

?>

	</div><!-- #content -->

	 <section class="foot">
        <div class="container">
       
            <div class="row">
                <div class="col-md-4 wow flipInX">
                    <h3 style="color:white;">GET IN TOUCH</h3><br>
					<p style="color:white"><i class="fa fa-dot-circle-o" aria-hidden="true" style="color:white"></i> No.1 Elsworth Rd,Belgravia,Harare</p>
					<p style="color:white"><i class="fa fa-phone" aria-hidden="true" style="color:white"></i> +263 (4) 790568,+263 (4) 790603 </p>
					<p style="color:white"><i class="fa fa-envelope" aria-hidden="true" style="color:white"></i> realestate@hammerandtongues.com </p>


                </div>

                <div class="col-md-4 wow flipInX">
                    <h3 style="color:white;">SOCIAL</h3><br>
					<p style="color:white"><i class="fa fa-facebook-square" aria-hidden="true" style="color:white"></i> <a href="https://www.facebook.com/Hammer-and-Tongues-Real-Estate-1898048030417923/?hc_ref=SEARCH&fref=nf" target="blank">Facebook</a></p>
					<p style="color:white"><i class="fa fa-twitter-square" aria-hidden="true" style="color:white"></i> <a href="https://twitter.com/handtproperty" target="blank">Twitter</a></p>
					<p style="color:white"><i class="fa fa-instagram-square" aria-hidden="true" style="color:white"></i> <a href="https://www.instagram.com/hntrealestate/" target="blank">Instagram</a></p>
					
                </div>

            </div>
         </div>
         </section>
		 <section class="copyright">
        <div class="container">
                <div class="row">
                <div class="col-lg-12">
					<p style="color:white">Copyright 2017 Hammer & Tongues.All Rights Reserved</p>
					</div>
					</div>
					</div>
		</section>	 
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
