<?php
/**
 * Template Name: Home Page
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Tinashe
 */

get_header(); ?>
	
		<?php echo do_shortcode('[tx_slider style="default" category="" delay="8000" parallax="yes" items="4" transition="fade" title="show" desc="show" link="show" align="left" height="480" textbg="shadow"]'); ?>

	<!-- Page Content -->
    <div class="container" style="margin-top:20px">

        <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-md-6">
            <h2 style="color:#CF0015">HAMMER & TONGUES<br>REAL ESTATE<br></h2><br>
           <p>Registered with the Real Estate Institution of Zimbabwe,Hammer and Tongues Real Estate (Pvt) Ltd has become the estate agent of choice backed by a reputable brand name financial stability and unparalled levels of professionalism</p>
           <p>Hammer and Tongues Real Estate is the distinct leader and auctioneer of choice in property auctions.Its bi-monthly public auctions on behalf of banks,liquidators and private individuals are highly attended</p>
            </div>
            <div class="col-md-6">
               <img src="<?php echo get_template_directory_uri(); ?>/images/1.jpg" alt="Logo"/>
            </div>
        </div>
        <div class="row">
             <h2 class="page-header" style="text-align:center;color:#CF0015">
                    OUR SERVICES
                </h2>
            <div class="col-md-6 wow bounceIn">
                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-institution"></i> Property Valuations</h4>
                    </div>
                    <div class="panel-body">
                        <p>We pride in our experience & quality.We offer a highly objective valuation report which is practical and free bias.We take into account the components that the client demands and ensure is delivered.Our valuation team comprises highly qualified valuers</p>
                        <a href="#" class="btn btn-default">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 wow slideInRight">
                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-cube"></i> Property Sales by Private Treaty</h4>
                    </div>
                    <div class="panel-body">
                        <p>We carry out sales by private treaty in two ways<br>
                        <ul>
                        <li>All properties not taken up on auction are put on private treaty</li>
                        <li>Some clients choose not to have their properties sold by auction</li>
                        </ul>
                        </p>
                        <a href="#" class="btn btn-default">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <!--End of Container-->
		<!-- /.row -->
        <section class="booking">
<div class="container-fluid">
  <div class="col-md-12">
                <h3 style="text-align:center;color:white" class="wow swing">SELL YOUR PROPERTY <br><br> CALL US ON +263 4 790568</h3>
                </div>
</div>
</section>
<div class="container wow zoomIn">
            <div class="col-lg-12">
                <h2 class="page-header" style="text-align:center;color:#CF0015">FEATURED PROPERTY</h2>
            </div>
			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>
			</div>
			</div>

		</main><!-- #main -->
	</div><!-- #primary -->
	<div class="container">
       
        <hr>

        <!-- Call to Action Section -->
        <div class="well wow bounce">
            <div class="row">
                <div class="col-md-8">
                    <h4>Subscribe to Our Newsletter</h4>
                    <p>Subscribe to our newsletter and get latest news and updates on property auctions</p>
                </div>
                <div class="col-md-4">
                    <br>
                    <a class="btn btn-lg btn-danger btn-block" href="#">Subscribe</a>
                </div>
            </div>
        </div>

        <hr>
</div>

<?php
get_footer();
