<?php
/**
 * Template Name: No Listing
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Tinashe
 */

get_header(); ?>

	<section class="pageheader" style="margin-bottom:50px">
<div class="container-fluid">
  <div class="col-md-12">
                <h2 style="text-align:center;color:white;text-transform:uppercase"><?php wp_title(''); ?></h2>
                </div>
</div>
</section>
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-lg-12">

			<h2 style="text-align:center;padding:5%">Sorry No Property Listings At The Moment</h2>

     </div>

        </div>

	

<?php
get_footer();
