<?php
/**
 * Template Name: Properties Page
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Tinashe
 */

get_header(); ?>

	<section class="pageheader" style="margin-bottom:50px">
<div class="container-fluid">
  <div class="col-md-12">
                <h2 style="text-align:center;color:white;text-transform:uppercase"><?php wp_title(''); ?></h2>
                </div>
</div>
</section>
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-lg-12">

			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>

     </div>

        </div>

	

<?php
get_footer();
